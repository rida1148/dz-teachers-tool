
DZ Teacher's Tool — Modern landing page
Files:
- index.html
- assets/css/styles.css
- assets/js/app.js
- assets/img/* (badges placeholders)

How to use:
1. Unzip and test locally: open index.html in your browser.
2. Deploy to GitHub Pages or Netlify (both free and support custom domain).
   - GitHub Pages: push repo, enable Pages on main branch -> site at https://<user>.github.io/<repo>/
   - Netlify: drag & drop folder to Netlify Sites -> instant deploy.
3. For custom domain, follow provider instructions and add CNAME/A records.

Contact:
Email: infoprofcem@gmail.com
Form: https://forms.gle/VMfN21YPeSyZbbik7
Privacy: https://firebasestorage.googleapis.com/v0/b/teachertooldz.firebasestorage.app/o/teacher_tool_privacy_policy.html?alt=media&token=efb6fe02-8967-4390-8b5b-fa0a02272662
